(async () => {
    const PLUGIN_NAME = '网络信号监控'
    const VERSION = 'v2.15'
    const LOG = (...a) => console.log(`[${PLUGIN_NAME}]`, ...a)

    // ========== 防重注入 + 自动升级替换 ==========
    const ROOT_ID = 'NET_SIG_MONITOR'
    const existing = document.getElementById(ROOT_ID)
    if (existing) {
        if (existing.dataset && existing.dataset.version === VERSION) {
            LOG(`已是 ${VERSION}，跳过重复加载`)
            return
        }
        existing.remove()
    }
    try {
        ['NS_BOX', 'REALTIME_MONITOR'].forEach(id => {
            const old = document.getElementById(id)
            if (old) old.remove()
        })
        document.querySelectorAll('style').forEach(s => {
            if (s.textContent && (s.textContent.indexOf('.rm-card') >= 0 || s.textContent.indexOf('NS_carriers') >= 0 || s.textContent.indexOf('NET_SIG') >= 0)) s.remove()
        })
        LOG('检测到旧版，已移除并升级到 ' + VERSION)
    } catch (e) { console.warn('[网络信号监控] 升级替换警告:', e) }

    // ========== 全局自诊断 ==========
    try { await main() }
    catch (e) {
        console.error('[网络信号监控] 致命错误:', e)
        try {
            const d = document.createElement('div')
            d.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#7a1a1a;color:#fff;padding:12px 16px;font-size:13px;font-family:monospace;line-height:1.6;word-break:break-all;'
            d.textContent = '❌ [网络信号监控] 加载失败: ' + (e && e.message || e)
            document.body.appendChild(d)
        } catch (e2) {}
    }

    async function main() {
        // ========== 底层执行 shim ==========
        if (typeof window.runShellWithRoot !== 'function') {
            window.runShellWithRoot = async (cmd, timeoutMs = 30000) => {
                try {
                    const base = (typeof KANO_baseURL !== 'undefined' && KANO_baseURL) ? KANO_baseURL : '/api'
                    const headers = { 'Content-Type': 'application/json' }
                    if (typeof common_headers !== 'undefined' && common_headers) {
                        Object.assign(headers, common_headers)
                        headers['Content-Type'] = 'application/json'
                    }
                    const res = await fetch(`${base}/run_shell`, {
                        method: 'POST', headers,
                        body: JSON.stringify({ cmd: String(cmd), timeout: Number(timeoutMs) || 30000 })
                    })
                    if (!res.ok) return { success: false, content: `HTTP ${res.status}` }
                    const t = await res.text()
                    try { const d = JSON.parse(t); return { success: !!d.success, content: d.content || '' } }
                    catch (e) { return { success: false, content: '解析失败: ' + t.slice(0, 100) } }
                } catch (e) { return { success: false, content: String(e && e.message || e) } }
            }
        }
        const sh = (cmd, t) => window.runShellWithRoot(cmd, t)

        const wait = (ms = 100) => new Promise(r => setTimeout(r, ms))
        {
            // UFI_DATA 只用于温度兜底，超时也不阻塞渲染（goform 才是主数据源）
            let _w = 0
            while (typeof UFI_DATA === 'undefined' || !UFI_DATA.lan_ipaddr) {
                if (_w >= 3000) { LOG('UFI_DATA 未就绪，跳过等待继续渲染'); break }
                await wait(); _w += 100
            }
        }

        // ========== goform 数据（与官方后台同源） ==========
        const goformGetAll = async () => {
            const base = (typeof KANO_baseURL !== 'undefined' && KANO_baseURL) ? KANO_baseURL : '/api'
            const headers = {}
            if (typeof common_headers !== 'undefined' && common_headers) {
                Object.assign(headers, common_headers)
                delete headers['Content-Type']
            }
            const res = await fetch(`${base}/goform/goform_get_cmd_process`, { headers })
            if (!res.ok) throw new Error(`HTTP ${res.status}`)
            return await res.json()
        }

        const rawGet = (d, key) => {
            if (!d) return undefined
            if (d[key] !== undefined && d[key] !== '' && d[key] !== null) return d[key]
            const lc = key.toLowerCase()
            if (d[lc] !== undefined && d[lc] !== '' && d[lc] !== null) return d[lc]
            const uc = key.toUpperCase()
            if (d[uc] !== undefined && d[uc] !== '' && d[uc] !== null) return d[uc]
            return undefined
        }
        const pick = (d, ...keys) => {
            for (const k of keys) { const v = rawGet(d, k); if (v !== undefined) return v }
            return undefined
        }

        // ========== 温度（CPU + 电池，2s 缓存；CPU 取 cpuss 最高，电池 type 匹配 + zone 兜底） ==========
        let lastTempTime = 0, cachedCpu = '--', cachedBat = '--'
        const getTemps = async (force) => {
            const now = Date.now()
            if (!force && cachedCpu !== '--' && cachedBat !== '--' && (now - lastTempTime) < 2000) {
                return { cpu: cachedCpu, bat: cachedBat }
            }
            lastTempTime = now
            const r = await sh(`
max=0
for z in /sys/class/thermal/thermal_zone*; do
    t=$(cat "$z/type" 2>/dev/null)
    case "$t" in cpuss-*) v=$(cat "$z/temp" 2>/dev/null); [ -n "$v" ] && [ "$v" -gt "$max" ] 2>/dev/null && max=$v;; esac
done
if [ "$max" -eq 0 ]; then
    for z in 16 17 18 19; do
        v=$(cat /sys/class/thermal/thermal_zone$z/temp 2>/dev/null)
        [ -n "$v" ] && [ "$v" -gt "$max" ] 2>/dev/null && max=$v
    done
fi
echo "C $max"
bt=0
for z in /sys/class/thermal/thermal_zone*; do
    t=$(cat "$z/type" 2>/dev/null)
    case "$t" in battery|bat*therm|battery-*) v=$(cat "$z/temp" 2>/dev/null); [ -n "$v" ] && [ "$v" -gt 0 ] 2>/dev/null && { bt=$v; break; };; esac
done
if [ "$bt" -eq 0 ]; then
    v=$(cat /sys/class/thermal/thermal_zone39/temp 2>/dev/null)
    [ -n "$v" ] && [ "$v" -gt 0 ] 2>/dev/null && bt=$v
fi
echo "B $bt"
`, 5000)
            const out = (r && r.content || '').trim()
            // CPU 温度（毫摄氏度 → 摄氏度）
            const cm = out.match(/^C (\d+)/m)
            if (cm && parseInt(cm[1]) > 0) cachedCpu = (parseInt(cm[1]) / 1000).toFixed(1)
            else cachedCpu = '--'
            // 电池温度（优先 thermal zone，其次 UFI_DATA 兜底）
            const bm = out.match(/^B (\d+)/m)
            if (bm && parseInt(bm[1]) > 0) cachedBat = (parseInt(bm[1]) / 1000).toFixed(1)
            else {
                const bt = parseFloat(rawGet(UFI_DATA, 'battery_temperature'))
                cachedBat = bt > 0 ? (bt / 10).toFixed(1) : '--'
            }
            return { cpu: cachedCpu, bat: cachedBat }
        }

        // ========== 格式化 ==========
        const fmtBytes = (b) => {
            b = Number(b) || 0
            if (b < 1048576) return (b / 1024).toFixed(1) + ' KB'
            if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB'
            return (b / 1073741824).toFixed(2) + ' GB'
        }
        // 只显示数字，不加单位（如 ↓1000 ↑100）
        const fmtAmbr = (b) => {
            if (!b || b <= 0) return null
            return String(Math.round(Number(b)))
        }
        // 设备固件 4G 不上报带宽字段，按频段号推算典型带宽（国内运营商标准值，仅供参考）
        const LTE_BW_EST = { 1: 20, 3: 20, 5: 5, 7: 20, 8: 5, 28: 10, 34: 20, 38: 20, 39: 20, 40: 20, 41: 20, 42: 20, 48: 20, 66: 20, 71: 10 }
        const estimateLteBw = (bandStr) => {
            const m = String(bandStr || '').match(/\d+/)
            if (!m) return null
            const est = LTE_BW_EST[parseInt(m[0])]
            return est ? est : null
        }
        // 带宽显示：真实值 → 估算(~) → 无数据(-)
        const bwDisp = (realVal, estVal) => {
            if (realVal && parseBW(realVal) > 0) return parseBW(realVal) + ' MHz'
            if (estVal) return '~' + estVal + ' MHz'
            return '-'
        }
        // 运营商名称汉化（China Mobile → 中国移动）
        const cnCarrier = (name) => {
            if (!name || name === '--') return name
            const s = String(name).trim().toLowerCase()
            const rules = [
                [/china\s*mobile|cmcc|中国移动/, '中国移动'],
                [/china\s*unicom|cucc|中国联通/, '中国联通'],
                [/china\s*telecom|ctcc|中国电信/, '中国电信'],
                [/china\s*broadcasting|cbn|中国广电|广播/, '中国广电']
            ]
            for (let i = 0; i < rules.length; i++) {
                if (rules[i][0].test(s)) return rules[i][1]
            }
            return name
        }
        const parseBW = (s) => {
            if (s == null || s === '' || s === '--') return 0
            s = String(s).replace(/[^0-9.]/gi, '').trim()
            const v = parseFloat(s); return isNaN(v) ? 0 : v
        }

        // ========== 信号颜色 ==========
        // 信号色 3 级（绿/黄/红）+ 无数据白色（去紫色）
        const rsrpC = (v) => { v = parseInt(v); if (isNaN(v)) return '#fff'; if (v >= -90) return '#22c55e'; if (v >= -100) return '#fbbf24'; return '#ef4444' }
        const rsrqC = (v) => { v = parseFloat(v); if (isNaN(v)) return '#fff'; if (v >= -10) return '#22c55e'; if (v >= -15) return '#fbbf24'; return '#ef4444' }
        const snrC  = (v) => { v = parseFloat(v); if (isNaN(v)) return '#fff'; if (v >= 10) return '#22c55e'; if (v >= 5) return '#fbbf24'; return '#ef4444' }
        const rssiC = (v) => { v = parseInt(v); if (isNaN(v)) return '#fff'; if (v >= -70) return '#22c55e'; if (v >= -80) return '#fbbf24'; return '#ef4444' }

        // ========== 综合网络质量评测 ==========
        // 权重：RSRP 35% / RSRQ 20% / RSSI 15% / SINR 30%。缺失指标不参与平均，避免误判。
        const qualityMetricDefs = [
            { key: 'rsrp', label: 'RSRP', unit: 'dBm', weight: 35, thresholds: [[-85, 100], [-95, 80], [-105, 55], [-120, 20]], color: rsrpC },
            { key: 'rsrq', label: 'RSRQ', unit: 'dB',  weight: 20, thresholds: [[-10, 100], [-15, 80], [-20, 55], [-30, 20]], color: rsrqC },
            { key: 'rssi', label: 'RSSI', unit: 'dBm', weight: 15, thresholds: [[-65, 100], [-75, 80], [-85, 55], [-100, 20]], color: rssiC },
            { key: 'sinr', label: 'SINR', unit: 'dB',  weight: 30, thresholds: [[20, 100], [13, 80], [5, 55], [0, 20]], color: snrC }
        ]
        const metricNumber = (v) => {
            if (v == null || v === '' || v === '--') return null
            const n = parseFloat(String(v).replace(/,/g, ''))
            return Number.isFinite(n) ? n : null
        }
        const fmtMetric = (v) => {
            const n = metricNumber(v)
            if (n == null) return '--'
            return n.toFixed(2).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1')
        }
        // 基站未真正下放/激活 SCell 时，常见为一组极差占位值。
        // 只有至少 3 项同时落入“未加载”区间才判定为无效，避免误伤真实弱覆盖。
        const isCarrierLoaded = (metrics) => {
            const rsrp = metricNumber(metrics.rsrp), rsrq = metricNumber(metrics.rsrq)
            const rssi = metricNumber(metrics.rssi), sinr = metricNumber(metrics.sinr)
            const extreme = [
                rsrp != null && rsrp <= -135,
                rsrq != null && rsrq <= -35,
                rssi != null && rssi <= -115,
                sinr != null && sinr <= -15
            ].filter(Boolean).length
            const hasMetric = [rsrp, rsrq, rssi, sinr].some(v => v != null)
            if (!hasMetric) return false
            return extreme < 3
        }
        const scoreMetric = (value, thresholds) => {
            for (const [min, score] of thresholds) if (value >= min) return score
            return 0
        }
        const qualityGrade = (score) => {
            if (score >= 90) return { label: '优秀', color: '#22c55e', desc: '信号强、干扰低，适合高速下载、高清视频和低时延业务' }
            if (score >= 75) return { label: '良好', color: '#86efac', desc: '整体稳定，大多数业务可正常使用，仍有小幅波动空间' }
            if (score >= 55) return { label: '一般', color: '#fbbf24', desc: '可用但存在覆盖或干扰问题，速率和稳定性可能波动' }
            return { label: '较差', color: '#ef4444', desc: '覆盖弱或干扰明显，建议调整设备位置、天线方向或网络制式' }
        }
        const evaluateSignalQuality = (metrics) => {
            let weighted = 0, weight = 0
            const rows = []
            qualityMetricDefs.forEach(def => {
                const value = metricNumber(metrics[def.key])
                if (value == null) return
                const score = scoreMetric(value, def.thresholds)
                weighted += score * def.weight
                weight += def.weight
                rows.push({ ...def, value, score })
            })
            if (!rows.length) return { available: 0, score: null, grade: { label: '暂无数据', color: '#94a3b8', desc: '等待基站返回 RSRP、RSRQ、RSSI、SINR 数据' }, rows }
            const score = Math.round(weighted / weight)
            const grade = qualityGrade(score)
            const weakest = rows.reduce((a, b) => a.score < b.score ? a : b)
            return { available: rows.length, score, grade, weakest, rows }
        }

        // 多载波评测：逐载波计算后加权，避免只看 PCell 掩盖 SCell 弱覆盖或强干扰。
        // 主/协同载波权重略高，辅载波按带宽参与；最终额外保留 25% 最弱载波保护。
        const evaluateCarrierQuality = (carriers) => {
            const evaluated = carriers
                .filter(c => isCarrierLoaded(c.metrics))
                .map(c => ({ ...c, assessment: evaluateSignalQuality(c.metrics) }))
                .filter(c => c.assessment.score != null)
            if (!evaluated.length) return { ...evaluateSignalQuality({}), carrierCount: 0, carriers: [] }

            const weightOf = (carrier) => {
                const roleWeight = carrier.role === '辅载波' ? 0.9 : (carrier.role === '主载波' ? 1.2 : 1.0)
                const bw = metricNumber(carrier.bandwidth)
                const bwWeight = bw == null ? 1 : Math.max(0.75, Math.min(1.5, bw / 20))
                return roleWeight * bwWeight
            }
            let total = 0, totalWeight = 0
            evaluated.forEach(c => {
                const w = weightOf(c)
                total += c.assessment.score * w
                totalWeight += w
            })
            const averageScore = totalWeight ? total / totalWeight : 0
            const weakestCarrier = evaluated.reduce((a, b) => a.assessment.score < b.assessment.score ? a : b)
            const score = Math.round(averageScore * 0.75 + weakestCarrier.assessment.score * 0.25)
            const grade = qualityGrade(score)

            const rows = qualityMetricDefs.map(def => {
                const values = evaluated.map(c => ({ value: metricNumber(c.metrics[def.key]), weight: weightOf(c) }))
                    .filter(x => x.value != null)
                if (!values.length) return null
                const sumWeight = values.reduce((n, x) => n + x.weight, 0)
                const value = values.reduce((n, x) => n + x.value * x.weight, 0) / sumWeight
                return { ...def, value, score: scoreMetric(value, def.thresholds), carrierValues: values.length }
            }).filter(Boolean)

            return {
                available: rows.length, score, grade, rows,
                carrierCount: evaluated.length,
                weakest: { label: weakestCarrier.label, score: weakestCarrier.assessment.score },
                carriers: evaluated
            }
        }

        const signalBars = (n) => {
            n = parseInt(n) || 0
            const colors = ['#ef4444','#f97316','#fbbf24','#86efac','#22c55e']
            let h = '<div style="display:flex;gap:3px;align-items:flex-end;height:28px">'
            for (let i = 1; i <= 5; i++) {
                const a = i <= n, c = a ? colors[Math.min(n - 1, 4)] : 'rgba(255,255,255,.16)'
                h += `<div style="width:7px;height:${7+i*4}px;border-radius:2px;background:${c};box-shadow:${a?'0 0 8px '+c+'80':'none'};transition:all .3s"></div>`
            }
            return h + '</div>'
        }

        // ===== 黑底 / 彩色数字 / 系统字体 =====
        const F = "font-family:-apple-system,'PingFang SC','Helvetica Neue',sans-serif"
        const CARD = 'background:rgba(255,255,255,0.08);border-radius:16px;border:1px solid rgba(255,255,255,0.18);box-shadow:0 8px 32px rgba(0,0,0,0.15);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px)'

        const sigCard = (label, val, unit, color) => {
            const v = fmtMetric(val)
            const hasVal = v !== '--'
            const c = color || (hasVal ? '#fff' : '#3a3f4b')
            return `<div style="text-align:center;padding:10px 2px">
                <div style="font-size:9px;color:rgba(255,255,255,0.55);margin-bottom:5px;font-weight:600;text-transform:uppercase;letter-spacing:.5px">${label}</div>
                <div style="font-size:16px;font-weight:800;color:${c};${F};line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-shadow:none">${v}</div>
                <div style="font-size:9px;color:rgba(255,255,255,0.45);margin-top:3px">${unit}</div>
            </div>`
        }

        const bandTag = (label, val) => {
            const hasVal = val && val !== '--'
            return `<span style="white-space:nowrap;display:inline-flex;align-items:center;gap:5px">
                <span style="font-size:10px;color:rgba(255,255,255,0.78);font-weight:700;text-transform:uppercase;letter-spacing:.5px">${label}</span>
                <span style="font-size:15px;font-weight:800;color:${hasVal ? '#fff' : 'rgba(255,255,255,.3)'};${F};text-shadow:0 1px 2px rgba(0,0,0,.4)">${val || '--'}</span>
            </span>`
        }

        const infoBarHTML = (items) => {
            let tags = ''
            items.forEach(([label, val]) => { tags += bandTag(label, val) })
            return `<div style="margin-bottom:10px;padding:8px 12px;background:rgba(255,255,255,0.07);border-radius:8px;border:1px solid rgba(255,255,255,0.12);display:flex;flex-wrap:wrap;gap:4px 16px;align-items:center">${tags}</div>`
        }

        const sectionTitleHTML = (text, subtitle, color) =>
            `<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
                <div style="width:3px;height:16px;border-radius:2px;background:${color};box-shadow:none"></div>
                <span style="font-size:15px;font-weight:800;color:#fff;${F};text-shadow:0 1px 3px rgba(0,0,0,.4)">${text}</span>
                <span style="font-size:9px;color:rgba(255,255,255,0.7);padding:2px 8px;border-radius:8px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;border:1px solid rgba(255,255,255,0.25);background:rgba(255,255,255,0.08)">${subtitle}</span>
            </div>`

        const carrierCard = (title, subtitle, color, infoItems, sigCards) =>
            `<div style="margin-top:8px;padding:14px;background:rgba(255,255,255,0.07);border-radius:12px;border:1px solid rgba(255,255,255,0.14)">
                ${sectionTitleHTML(title, subtitle, color)}
                ${infoBarHTML(infoItems)}
                <div class="nsc-signal-grid">${sigCards}</div>
            </div>`

        // ===== 解析 nrca/lteca =====
        const parseCAState = (stateStr, isNR) => {
            if (!stateStr || typeof stateStr !== 'string') return []
            const s = String(stateStr).trim()
            if (s === '0' || s === '' || s === 'false' || s === 'off') return []
            const cells = []
            const hPattern = /\(H:\s*([^)]+)\)/gi
            let m
            while ((m = hPattern.exec(s)) !== null) {
                const parts = m[1].split(',').map(v => v.trim())
                if (parts.length >= 8) {
                    cells.push({
                        type: parseInt(parts[0]) || 0, pci: parts[1] || '',
                        band: (isNR ? 'N' : 'B') + (parts[3] || ''), arfcn: parts[4] || '', bandwidth: parts[5] || '',
                        rsrp: parts[7] || null, rsrq: parts[8] || null, sinr: parts[9] || null,
                        rssi: parts[10] || null, isNR
                    })
                }
            }
            if (cells.length === 0) {
                const seqPattern = /(\d+),(\d+),(\d+),(\d+),(\d+),(\d+),(-?\d+),(-?[\d.]+),(-?[\d.]+),(-?[\d.]+)/g
                while ((m = seqPattern.exec(s)) !== null) {
                    const afterSinr = s.substring(m.index + m[0].length)
                    const rssiMatch = afterSinr.match(/^,(-?[\d.]+)/)
                    cells.push({
                        type: parseInt(m[1]) || 0, pci: m[2],
                        band: (isNR ? 'N' : 'B') + m[4], arfcn: m[5], bandwidth: m[6],
                        rsrp: m[8], rsrq: m[9], sinr: m[10],
                        rssi: rssiMatch ? rssiMatch[1] : null, isNR
                    })
                }
            }
            if (cells.length === 0) {
                const chunks = s.split(/[;|\n]/)
                for (const chunk of chunks) {
                    const nums = chunk.match(/-?\d+\.?\d*/g)
                    if (nums && nums.length >= 8) {
                        cells.push({
                            type: parseInt(nums[0]) || 0, pci: nums[1] || '',
                            band: (isNR ? 'N' : 'B') + (nums[3] || ''), arfcn: nums[4] || '', bandwidth: nums[5] || '',
                            rsrp: nums[7] || null, rsrq: nums[8] || null, sinr: nums[9] || null, rssi: nums[10] || null, isNR
                        })
                    }
                }
            }
            return cells
        }

        // ===== 注入 UI（黑底 / 彩色数字 / 系统字体，载波默认折叠） =====
        const container = document.querySelector('.functions-container') || document.body
        container.insertAdjacentHTML('afterend', `
<style id="NSM_modern_css">
#NET_SIG_MONITOR{width:100%;margin-top:10px;position:relative;color:#eaf2ff;${F};}
#NET_SIG_MONITOR *{box-sizing:border-box;}
#NET_SIG_MONITOR .nsc-shell{background:linear-gradient(145deg,rgba(13,25,43,.96),rgba(18,35,55,.96));border:1px solid rgba(148,163,184,.18);border-radius:18px;box-shadow:0 12px 36px rgba(0,0,0,.22);overflow:hidden;}
#NET_SIG_MONITOR .nsc-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;border-bottom:1px solid rgba(148,163,184,.14);}
#NET_SIG_MONITOR .nsc-title{display:flex;align-items:center;gap:8px;min-width:0;font-size:15px;font-weight:800;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-title-icon{width:28px;height:28px;display:grid;place-items:center;border-radius:9px;background:linear-gradient(145deg,#2563eb,#06b6d4);font-size:16px;box-shadow:0 5px 14px rgba(37,99,235,.32);}
#NET_SIG_MONITOR .nsc-version{font-size:10px;color:#94a3b8;font-weight:600;}
#NET_SIG_MONITOR .nsc-actions{display:flex;gap:6px;flex:0 0 auto;}
#NET_SIG_MONITOR .nsc-action{border:1px solid rgba(96,165,250,.3);background:rgba(59,130,246,.1);color:#93c5fd;border-radius:999px;padding:5px 9px;font-size:10px;font-weight:800;cursor:pointer;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-body{padding:12px;}
#NET_SIG_MONITOR .nsc-hero{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;padding:14px;border-radius:14px;background:linear-gradient(135deg,rgba(37,99,235,.2),rgba(15,118,110,.12));border:1px solid rgba(96,165,250,.2);}
#NET_SIG_MONITOR .nsc-identity{display:flex;align-items:center;gap:11px;min-width:0;}
#NET_SIG_MONITOR .nsc-bars{width:42px;flex:0 0 42px;}
#NET_SIG_MONITOR .nsc-type{font-size:25px;line-height:1;font-weight:900;letter-spacing:-.6px;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-meta{display:flex;align-items:center;gap:7px;margin-top:6px;min-width:0;}
#NET_SIG_MONITOR .nsc-provider{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#cbd5e1;font-size:11px;font-weight:700;}
#NET_SIG_MONITOR .nsc-online{padding:3px 8px;border-radius:999px;font-size:9px;font-weight:900;white-space:nowrap;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);}
#NET_SIG_MONITOR .nsc-right{text-align:right;min-width:92px;}
#NET_SIG_MONITOR .nsc-bandwidth{font-size:22px;line-height:1;font-weight:900;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-caption{margin-top:4px;color:#94a3b8;font-size:9px;font-weight:800;letter-spacing:.8px;}
#NET_SIG_MONITOR .nsc-temp{margin-top:7px;font-size:10px;font-weight:800;line-height:1.5;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin-top:9px;}
#NET_SIG_MONITOR .nsc-stat{min-width:0;padding:9px 6px;border-radius:11px;background:rgba(255,255,255,.055);border:1px solid rgba(148,163,184,.13);text-align:center;}
#NET_SIG_MONITOR .nsc-stat-label{color:#94a3b8;font-size:9px;font-weight:800;}
#NET_SIG_MONITOR .nsc-stat-value{margin-top:4px;color:#e2e8f0;font-size:13px;font-weight:850;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
#NET_SIG_MONITOR .nsc-speed{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:9px;padding:9px 11px;border-radius:11px;background:rgba(168,85,247,.09);border:1px solid rgba(192,132,252,.28);}
#NET_SIG_MONITOR .nsc-speed-label{color:#86efac;font-size:11px;font-weight:900;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-speed-value{min-width:0;color:#e9d5ff;font-size:11px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:right;}
#NET_SIG_MONITOR .nsc-quality{margin-top:10px;padding:13px;border-radius:14px;background:rgba(15,23,42,.55);border:1px solid rgba(96,165,250,.24);}
#NET_SIG_MONITOR .nsc-quality-head{display:flex;align-items:center;justify-content:space-between;gap:10px;}
#NET_SIG_MONITOR .nsc-quality-title{font-size:14px;font-weight:900;color:#f8fafc;}
#NET_SIG_MONITOR .nsc-quality-desc{margin-top:4px;color:#94a3b8;font-size:10px;line-height:1.45;}
#NET_SIG_MONITOR .nsc-score{display:flex;align-items:baseline;gap:3px;flex:0 0 auto;padding:5px 9px;border-radius:11px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);white-space:nowrap;}
#NET_SIG_MONITOR .nsc-score-number{font-size:27px;line-height:1;font-weight:950;}
#NET_SIG_MONITOR .nsc-score-unit{font-size:10px;color:#94a3b8;font-weight:800;}
#NET_SIG_MONITOR .nsc-grade{margin-left:4px;font-size:11px;font-weight:900;}
#NET_SIG_MONITOR .nsc-signal-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;}
#NET_SIG_MONITOR .nsc-quality-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:10px;}
#NET_SIG_MONITOR .nsc-quality-metric{min-width:0;padding:8px 4px;border-radius:9px;background:rgba(255,255,255,.055);text-align:center;}
#NET_SIG_MONITOR .nsc-quality-metric-value{margin-top:3px;font-size:14px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
#NET_SIG_MONITOR .nsc-standards{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px;padding:8px 10px;border-radius:9px;background:rgba(96,165,250,.08);color:#93c5fd;font-size:11px;font-weight:900;cursor:pointer;}
#NET_SIG_MONITOR .nsc-std-stack{display:grid;gap:7px;}
#NET_SIG_MONITOR .nsc-std-card{padding:9px 10px;border-radius:10px;background:rgba(255,255,255,.045);border:1px solid rgba(148,163,184,.12);}
#NET_SIG_MONITOR .nsc-std-title{display:flex;align-items:center;justify-content:space-between;gap:8px;color:#e2e8f0;font-size:11px;font-weight:900;}
#NET_SIG_MONITOR .nsc-std-title span:last-child{color:#93c5fd;font-size:9px;font-weight:800;white-space:nowrap;}
#NET_SIG_MONITOR .nsc-std-body{margin-top:5px;color:#aab7c8;font-size:10px;line-height:1.55;}
#NET_SIG_MONITOR .nsc-std-note{margin-top:7px;padding:7px 8px;border-radius:8px;background:rgba(15,23,42,.38);color:#94a3b8;font-size:10px;line-height:1.55;}
#NET_SIG_MONITOR .nsc-carriers-toggle{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px;padding:10px 11px;border-radius:11px;background:rgba(255,255,255,.055);border:1px solid rgba(148,163,184,.14);cursor:pointer;}
#NET_SIG_MONITOR .nsc-carriers-content{margin-top:6px;}
#NET_SIG_MONITOR .nsc-foot-log{display:none;}
@media (max-width:620px){#NET_SIG_MONITOR .nsc-body{padding:10px;}#NET_SIG_MONITOR .nsc-head{padding:10px 11px;}#NET_SIG_MONITOR .nsc-title{font-size:14px;}#NET_SIG_MONITOR .nsc-action{padding:5px 8px;font-size:10px;}#NET_SIG_MONITOR .nsc-hero{grid-template-columns:minmax(0,1fr) auto;padding:12px 11px;gap:8px;}#NET_SIG_MONITOR .nsc-type{font-size:22px;}#NET_SIG_MONITOR .nsc-provider{max-width:118px;}#NET_SIG_MONITOR .nsc-bandwidth{font-size:19px;}#NET_SIG_MONITOR .nsc-right{min-width:82px;}#NET_SIG_MONITOR .nsc-stats{grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;}#NET_SIG_MONITOR .nsc-signal-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;}#NET_SIG_MONITOR .nsc-quality-head{align-items:flex-start;}#NET_SIG_MONITOR .nsc-quality-title{font-size:13px;}#NET_SIG_MONITOR .nsc-score-number{font-size:24px;}#NET_SIG_MONITOR .nsc-quality-metrics{grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;}}
@media (max-width:360px){#NET_SIG_MONITOR .nsc-head{align-items:flex-start;}#NET_SIG_MONITOR .nsc-actions{gap:4px;}#NET_SIG_MONITOR .nsc-action{padding:4px 6px;font-size:9px;}#NET_SIG_MONITOR .nsc-hero{grid-template-columns:minmax(0,1fr);}#NET_SIG_MONITOR .nsc-right{text-align:left;display:flex;align-items:center;gap:9px;min-width:0;}#NET_SIG_MONITOR .nsc-temp{margin-top:0;}}
</style>
<div id="NET_SIG_MONITOR" data-version="${VERSION}" class="nsc-root">
 <div class="nsc-shell">
  <div class="nsc-head"><div class="nsc-title"><span class="nsc-title-icon">📶</span><span>${PLUGIN_NAME}</span><span class="nsc-version">${VERSION}</span></div><div class="nsc-actions"><a id="NSM_collapse_btn" class="nsc-action">▼ 收起</a><a id="NSM_detail_btn" class="nsc-action">详情 ›</a></div></div>
  <div id="NSM_body" class="nsc-body">
   <div class="nsc-hero"><div class="nsc-identity"><div id="NSM_bars" class="nsc-bars"></div><div style="min-width:0"><div style="display:flex;align-items:center;gap:7px"><span id="NSM_type" class="nsc-type">--</span><span id="NSM_ca_badge" style="display:none;font-size:9px;font-weight:900;padding:3px 7px;border-radius:999px;letter-spacing:.8px">CA</span></div><div class="nsc-meta"><span id="NSM_carrier" class="nsc-provider">--</span><span id="NSM_online" class="nsc-online">--</span></div></div></div><div class="nsc-right"><div id="NSM_bw_total" class="nsc-bandwidth">--</div><div class="nsc-caption">总带宽</div><div id="NSM_temp" class="nsc-temp">--</div></div></div>
   <div class="nsc-stats"><div class="nsc-stat"><div class="nsc-stat-label">今日流量</div><div id="NSM_day_data" class="nsc-stat-value">--</div></div><div class="nsc-stat"><div class="nsc-stat-label">本月流量</div><div id="NSM_month_data" class="nsc-stat-value">--</div></div><div class="nsc-stat"><div class="nsc-stat-label">服务等级</div><div id="NSM_qci_val" class="nsc-stat-value" style="color:#86efac">--</div></div><div class="nsc-stat"><div class="nsc-stat-label">更新时间</div><div id="NSM_time" class="nsc-stat-value">--</div></div></div>
   <div class="nsc-speed"><span class="nsc-speed-label">⚡ 签约速度</span><div id="NSM_ambr" class="nsc-speed-value">--</div></div>
   <div id="NSM_quality" class="nsc-quality"><div class="nsc-quality-head"><div style="min-width:0"><div class="nsc-quality-title">网络质量综合评测</div><div id="NSM_quality_desc" class="nsc-quality-desc">等待数据...</div></div><div class="nsc-score"><span id="NSM_quality_score" class="nsc-score-number">--</span><span class="nsc-score-unit">/100</span><span id="NSM_quality_grade" class="nsc-grade">暂无数据</span></div></div><div id="NSM_quality_metrics" class="nsc-quality-metrics"></div><div id="NSM_quality_std_toggle" class="nsc-standards"><span>详细评测标准</span><span id="NSM_quality_std_arrow">▶ 展开</span></div><div id="NSM_quality_standards" style="display:none;margin-top:8px"><div class="nsc-std-stack"><div class="nsc-std-card"><div class="nsc-std-title"><span>单载波：独立质量评分</span><span>1 个有效载波</span></div><div class="nsc-std-body">RSRP 35%：覆盖强度；RSRQ 20%：信道质量；RSSI 15%：接收总功率；SINR 30%：抗干扰能力。四项按权重合计为最终分数：≥90 优秀，75–89 良好，55–74 一般，&lt;55 较差。</div></div><div class="nsc-std-card"><div class="nsc-std-title"><span>双载波：主载波 + 1 个辅载波</span><span>有效载波数 = 2</span></div><div class="nsc-std-body">先分别计算 PCell 与 SCell 的四项指标分数，再按载波角色与带宽合成。主载波体现连接稳定性，辅载波体现聚合增益；综合分保留弱辅载波 25% 的影响，避免主载波很好但辅载波很差时仍被评为满分。</div></div><div class="nsc-std-card"><div class="nsc-std-title"><span>三载波：主载波 + 2 个辅载波</span><span>有效载波数 = 3</span></div><div class="nsc-std-body">先逐一评估 PCell、SCell1、SCell2，再按角色、带宽和信号质量合成。总评分以有效载波加权平均为基础，并保留最弱载波 25% 的影响；任一辅载波明显恶化时，评分会体现聚合链路的实际短板。</div></div><div class="nsc-std-card"><div class="nsc-std-title"><span>辅载波是否真正加载</span><span>不满足则不计入</span></div><div class="nsc-std-body">当 RSRP ≤−135、RSRQ ≤−35、RSSI ≤−115、SINR ≤−15 中至少 3 项同时出现时，判定辅载波未被基站实际下放或尚未激活。</div><div class="nsc-std-note">未加载辅载波不计入网络质量评分、有效载波数量、总带宽、CA 状态和最弱载波惩罚。示例：RSRP −140、RSRQ −43、RSSI −120、SINR −23 将被排除。</div></div><div class="nsc-std-note">通用说明：缺失指标不参与该载波的指标平均；只有有效载波参与 CA 评估。单载波看稳定性，双载波看主辅协同，三载波看整体吞吐与最弱环节。</div></div></div></div></div>
   <div id="NSM_carriers_toggle" class="nsc-carriers-toggle"><div style="display:flex;align-items:center;gap:8px"><span style="font-size:12px;font-weight:900;color:#cbd5e1">载波详情</span><span id="NSM_carriers_count" style="font-size:10px;color:#94a3b8;background:rgba(255,255,255,.08);padding:3px 8px;border-radius:999px">--</span></div><span id="NSM_carriers_arrow" style="font-size:11px;color:#94a3b8">▶ 展开</span></div>
   <div id="NSM_carriers_content" class="nsc-carriers-content" style="display:none"></div><div id="NSM_log" class="nsc-foot-log"></div>
  </div>
 </div>
</div>`)
        // ===== 载波折叠（默认收起） =====
        const carriersToggle = document.getElementById('NSM_carriers_toggle')
        const carriersContent = document.getElementById('NSM_carriers_content')
        const carriersArrow = document.getElementById('NSM_carriers_arrow')
        const carriersCount = document.getElementById('NSM_carriers_count')
        const CARRIERS_KEY = 'NSM_carriers_expanded'
        const setCarriersOpen = (open) => {
            carriersContent.style.display = open ? 'block' : 'none'
            carriersArrow.textContent = open ? '▼ 收起' : '▶ 展开'
            localStorage.setItem(CARRIERS_KEY, open ? '1' : '0')
        }
        carriersToggle.addEventListener('click', () => {
            setCarriersOpen(carriersContent.style.display === 'none')
        })

        // ===== 全局折叠（只保留标题行） =====
        const bodyDom = document.getElementById('NSM_body')
        const collapseBtn = document.getElementById('NSM_collapse_btn')
        const COLLAPSE_KEY = 'NSM_collapsed'
        const setCollapsed = (collapsed) => {
            bodyDom.style.display = collapsed ? 'none' : 'block'
            collapseBtn.textContent = collapsed ? '▶ 展开' : '▼ 收起'
            localStorage.setItem(COLLAPSE_KEY, collapsed ? '1' : '0')
        }
        collapseBtn.addEventListener('click', () => {
            setCollapsed(bodyDom.style.display !== 'none')
        })

        // ===== 日志 =====
        const qualityDesc = document.getElementById('NSM_quality_desc')
        const qualityScore = document.getElementById('NSM_quality_score')
        const qualityGradeEl = document.getElementById('NSM_quality_grade')
        const qualityMetrics = document.getElementById('NSM_quality_metrics')
        const qualityStdToggle = document.getElementById('NSM_quality_std_toggle')
        const qualityStandards = document.getElementById('NSM_quality_standards')
        const qualityStdArrow = document.getElementById('NSM_quality_std_arrow')
        const QUALITY_STD_KEY = 'NSM_quality_standards_expanded'
        const setQualityStandardsOpen = (open) => {
            qualityStandards.style.display = open ? 'block' : 'none'
            qualityStdArrow.textContent = open ? '▼ 收起' : '▶ 展开'
            localStorage.setItem(QUALITY_STD_KEY, open ? '1' : '0')
        }
        qualityStdToggle.addEventListener('click', () => {
            setQualityStandardsOpen(qualityStandards.style.display === 'none')
        })
        const renderQuality = (assessment) => {
            const grade = assessment.grade
            qualityScore.textContent = assessment.score == null ? '--' : String(assessment.score)
            qualityScore.style.color = grade.color
            qualityGradeEl.textContent = grade.label
            qualityGradeEl.style.color = grade.color
            const carrierHint = assessment.carrierCount ? ` · 已评测 ${assessment.carrierCount} 个载波` : ''
            const weakHint = assessment.weakest ? ` · 重点关注 ${assessment.weakest.label}` : ''
            qualityDesc.textContent = assessment.score == null ? grade.desc : grade.desc + carrierHint + weakHint
            qualityMetrics.innerHTML = qualityMetricDefs.map(def => {
                const row = assessment.rows.find(x => x.key === def.key)
                const value = row ? fmtMetric(row.value) : '--'
                const score = row ? row.score : null
                const color = row ? def.color(row.value) : '#64748b'
                return `<div class="nsc-quality-metric">
                    <div style="font-size:9px;color:rgba(255,255,255,.52);font-weight:700">${def.label} <span style="font-weight:400">${def.weight}%</span></div>
                    <div class="nsc-quality-metric-value" style="color:${color};${F}">${value}</div>
                    <div style="font-size:9px;color:${color};margin-top:2px">${score == null ? '无数据' : score + '分'}</div>
                </div>`
            }).join('')
        }

        // ===== 日志 =====
        const logDom = document.getElementById('NSM_log')
        const pushLog = (msg, type) => {
            const div = document.createElement('div')
            div.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`
            if (type === 'warn') div.style.color = '#fbbf24'
            else if (type === 'error') div.style.color = '#f87171'
            else div.style.color = '#60a5fa'
            logDom.appendChild(div)
            while (logDom.children.length > 200) logDom.removeChild(logDom.firstChild)
            logDom.scrollTop = logDom.scrollHeight
        }

        // ===== 刷新逻辑 =====
        let refreshing = false
        const refresh = async () => {
            if (refreshing) return
            refreshing = true
            try {
                const d = await goformGetAll()

                document.getElementById('NSM_bars').innerHTML = signalBars(pick(d, 'network_signalbar'))
                const ntype = pick(d, 'network_type') || '--'
                const is5G = ntype.includes('5G'), is4G = ntype.includes('4G') || ntype.includes('LTE')
                document.getElementById('NSM_carrier').textContent = cnCarrier(pick(d, 'network_provider_fullname', 'network_provider') || '--')

                const online = ntype !== '--' && !/no service|离线|无服务/i.test(ntype)
                const olEl = document.getElementById('NSM_online')
                olEl.textContent = online ? '在线' : '离线'
                olEl.style.color = online ? '#22c55e' : '#ef4444'
                olEl.style.borderColor = online ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)'

                const temps = await getTemps(false)
                document.getElementById('NSM_temp').innerHTML =
                    '<span style="color:#f97316">CPU ' + temps.cpu + '°C</span><br>' +
                    '<span style="color:#60a5fa">电池 ' + temps.bat + '°C</span>'

                const dr = pick(d, 'day_rx_bytes'), dt = pick(d, 'day_tx_bytes')
                const mr = pick(d, 'month_rx_bytes'), mt = pick(d, 'month_tx_bytes')
                document.getElementById('NSM_day_data').textContent = fmtBytes((+dr||0)+(+dt||0))
                document.getElementById('NSM_month_data').textContent = fmtBytes((+mr||0)+(+mt||0))
                document.getElementById('NSM_time').textContent = new Date().toLocaleTimeString()

                // QCI / 签约速度
                let qci = null, amDl = null, amUl = null
                const qciCandidates = Object.keys(d).filter(k => {
                    const lk = k.toLowerCase()
                    if (lk === 'qci') return true
                    if (lk.endsWith('_qci') || lk.endsWith('qci')) return true
                    return false
                }).filter(k => {
                    const lk = k.toLowerCase()
                    if (lk.includes('en') || lk.includes('enable') || lk.includes('switch') ||
                        lk.includes('support') || lk.includes('flag') || lk.includes('mask')) return false
                    return true
                }).sort((a, b) => a.length - b.length)
                for (const k of qciCandidates) {
                    const v = String(d[k]).trim()
                    const n = parseInt(v)
                    if (!isNaN(n) && n >= 1 && n <= 254) { qci = v; break }
                }
                for (const k of Object.keys(d)) {
                    const lk = k.toLowerCase()
                    if (lk.includes('en') || lk.includes('enable') || lk.includes('switch')) continue
                    const isDl = lk.includes('dl') || lk.includes('downlink')
                    const isUl = lk.includes('ul') || lk.includes('uplink')
                    const isRate = lk.includes('ambr') || lk.includes('am_br') || lk.includes('amr') || lk.includes('rate') || lk.includes('bitrate') || lk.includes('subs') || lk.includes('contract')
                    if (isRate && Number(d[k]) > 0) {
                        const n = Number(d[k])
                        if (isDl && !isUl && !amDl) amDl = n
                        else if (isUl && !isDl && !amUl) amUl = n
                        else if (!amDl) amDl = n
                    }
                }
                document.getElementById('NSM_qci_val').textContent = qci ? 'QCI ' + qci : '--'
                let ambrTxt = '--'
                const ambrParts = []
                if (amDl) ambrParts.push('↓' + fmtAmbr(amDl))
                if (amUl) ambrParts.push('↑' + fmtAmbr(amUl))
                if (ambrParts.length) ambrTxt = ambrParts.join(' ')
                document.getElementById('NSM_ambr').textContent = ambrTxt

                // 载波卡片（生成 + 显示在折叠区）
                const bwSum = { val: 0, est: 0 }
                let cardsHTML = ''
                const carrierCount = { v: 0 }

                const nrRsrp = pick(d,'Z5g_rsrp','nr_rsrp','Z5G_RSRP','NR_RSRP')
                const nrBand = pick(d,'Nr_bands','nr_bands','NR_BANDS')
                const nrBw = pick(d,'Nr_bands_widths','nr_bands_widths','NR_BANDS_WIDTHS',
                                      'nr_bandwidth','NR_Bandwidth','nr_dl_bandwidth')
                if (is5G || nrRsrp || nrBand) {
                    bwSum.val += parseBW(nrBw)
                    if (!parseBW(nrBw)) { const ne = estimateLteBw(pick(d,'Nr_bands','nr_bands')); if (ne) bwSum.est += ne }
                    const nrBwDisp = bwDisp(nrBw, null)
                    cardsHTML += carrierCard(
                        '5G NR', 'PCell · 主载波', '#3b82f6',
                        [['频段', pick(d,'Nr_bands','nr_bands')], ['频点', pick(d,'Nr_fcn','nr_fcn')], ['带宽', nrBwDisp], ['PCI', pick(d,'Nr_pci','nr_pci')]],
                        sigCard('RSRP', nrRsrp, 'dBm', rsrpC(nrRsrp)) +
                        sigCard('RSRQ', pick(d,'nr_rsrq','Nr_rsrq'), 'dB', rsrqC(pick(d,'nr_rsrq','Nr_rsrq'))) +
                        sigCard('RSSI', pick(d,'nr_rssi','Nr_rssi'), 'dBm', rssiC(pick(d,'nr_rssi','Nr_rssi'))) +
                        sigCard('SINR', pick(d,'Nr_snr','nr_snr'), 'dB', snrC(pick(d,'Nr_snr','nr_snr')))
                    )
                    carrierCount.v++
                }

                const nrCaState = pick(d, 'nrca', 'NRCA', 'nrca_state', 'nr_ca_state', 'nr5g_ca_status', 'nr5g_ca_state')
                const nrSCellsRaw = parseCAState(nrCaState, true)
                const nrSCells = nrSCellsRaw.filter(scc => isCarrierLoaded({ rsrp: scc.rsrp, rsrq: scc.rsrq, rssi: scc.rssi, sinr: scc.sinr }))
                const hasNRCA = nrSCells.length > 0
                if (hasNRCA) {
                    nrSCells.forEach(scc => {
                        const bw = scc.bandwidth ? (String(scc.bandwidth).includes('M') ? scc.bandwidth : scc.bandwidth + 'MHz') : '--'
                        bwSum.val += parseBW(scc.bandwidth)
                        cardsHTML += carrierCard(
                            '5G NR', 'SCell · 辅载波' + (scc.type > 0 ? ' ' + scc.type : ''), '#3b82f6',
                            [['频段', scc.band], ['频点', scc.arfcn], ['带宽', bw], ['PCI', scc.pci]],
                            sigCard('RSRP', scc.rsrp, 'dBm', rsrpC(scc.rsrp)) +
                            sigCard('RSRQ', scc.rsrq, 'dB', rsrqC(scc.rsrq)) +
                            sigCard('RSSI', scc.rssi, 'dBm', rssiC(scc.rssi)) +
                            sigCard('SINR', scc.sinr, 'dB', snrC(scc.sinr))
                        )
                        carrierCount.v++
                    })
                }

                const lteRsrp = pick(d,'lte_rsrp','LTE_RSRP')
                const lteBand = pick(d,'Lte_bands','lte_bands','LTE_BANDS')
                const lteBw = pick(d, 'Lte_bands_widths', 'lte_bands_widths', 'LTE_BANDS_WIDTHS',
                                          'lte_bandwidth', 'LTE_Bandwidth', 'LTE_BANDWIDTH', 'LTE_BandWidth',
                                          'lte_dl_bandwidth', 'lte_ul_bandwidth',
                                          'Lte_DL_BW', 'Lte_UL_BW', 'LTE_BW', 'lte_bw')
                if (is4G || lteRsrp || lteBand) {
                    bwSum.val += parseBW(lteBw)
                    if (!parseBW(lteBw)) { const le = estimateLteBw(lteBand); if (le) bwSum.est += le }
                    const lteBwDisp = bwDisp(lteBw, estimateLteBw(lteBand))
                    cardsHTML += carrierCard('4G LTE', 'PCell · 主载波', '#22c55e',
                        [['频段', pick(d,'Lte_bands','lte_bands')], ['频点', pick(d,'Lte_fcn','lte_fcn')], ['带宽', lteBwDisp], ['PCI', pick(d,'Lte_pci','lte_pci')]],
                        sigCard('RSRP', lteRsrp, 'dBm', rsrpC(lteRsrp)) +
                        sigCard('RSRQ', pick(d,'lte_rsrq','LTE_RSRQ'), 'dB', rsrqC(pick(d,'lte_rsrq','LTE_RSRQ'))) +
                        sigCard('RSSI', pick(d,'lte_rssi','LTE_RSSI'), 'dBm', rssiC(pick(d,'lte_rssi','LTE_RSSI'))) +
                        sigCard('SINR', pick(d,'Lte_snr','lte_snr','LTE_SNR'), 'dB', snrC(pick(d,'Lte_snr','lte_snr')))
                    )
                    carrierCount.v++
                }

                const lteCaState = pick(d, 'lteca', 'LTECA', 'lteca_state', 'lte_ca_state', 'wan_lte_ca')
                const lteSCellsRaw = parseCAState(lteCaState, false)
                const lteSCells = lteSCellsRaw.filter(scc => isCarrierLoaded({ rsrp: scc.rsrp, rsrq: scc.rsrq, rssi: scc.rssi, sinr: scc.sinr }))
                const hasLTECA = lteSCells.length > 0
if (hasLTECA) {
                    lteSCells.forEach(scc => {
                        const bw = scc.bandwidth ? (String(scc.bandwidth).includes('M') ? scc.bandwidth : scc.bandwidth + 'MHz') : '--'
                        bwSum.val += parseBW(scc.bandwidth)
                        cardsHTML += carrierCard('4G LTE', 'SCell · 辅载波' + (scc.type > 0 ? ' ' + scc.type : ''), '#22c55e',
                            [['频段', scc.band], ['频点', scc.arfcn], ['带宽', bw], ['PCI', scc.pci]],
                            sigCard('RSRP', scc.rsrp, 'dBm', rsrpC(scc.rsrp)) +
                            sigCard('RSRQ', scc.rsrq, 'dB', rsrqC(scc.rsrq)) +
                            sigCard('RSSI', scc.rssi, 'dBm', rssiC(scc.rssi)) +
                            sigCard('SINR', scc.sinr, 'dB', snrC(scc.sinr)))
                        carrierCount.v++
                    })
                }

                // 综合评测全部活动载波：PCell、协同载波与 SCell 均纳入。
                const qualityCarriers = []
                const addQualityCarrier = (label, role, metrics, bandwidth) => {
                    if (isCarrierLoaded(metrics)) qualityCarriers.push({ label, role, metrics, bandwidth })
                }
                addQualityCarrier('5G NR 主载波', is5G ? '主载波' : '协同载波', {
                    rsrp: nrRsrp, rsrq: pick(d,'nr_rsrq','Nr_rsrq'), rssi: pick(d,'nr_rssi','Nr_rssi'), sinr: pick(d,'Nr_snr','nr_snr')
                }, nrBw)
                nrSCells.forEach((scc, i) => addQualityCarrier(`5G NR 辅载波${i + 1}`, '辅载波', {
                    rsrp: scc.rsrp, rsrq: scc.rsrq, rssi: scc.rssi, sinr: scc.sinr
                }, scc.bandwidth))
                addQualityCarrier('4G LTE 主载波', is5G ? '协同载波' : '主载波', {
                    rsrp: lteRsrp, rsrq: pick(d,'lte_rsrq','LTE_RSRQ'), rssi: pick(d,'lte_rssi','LTE_RSSI'), sinr: pick(d,'Lte_snr','lte_snr','LTE_SNR')
                }, lteBw)
                lteSCells.forEach((scc, i) => addQualityCarrier(`4G LTE 辅载波${i + 1}`, '辅载波', {
                    rsrp: scc.rsrp, rsrq: scc.rsrq, rssi: scc.rssi, sinr: scc.sinr
                }, scc.bandwidth))
                renderQuality(evaluateCarrierQuality(qualityCarriers))

                carriersCount.textContent = carrierCount.v + ' 个'
                carriersContent.innerHTML = cardsHTML || `<div style="padding:20px;text-align:center;color:rgba(255,255,255,0.15);font-size:12px">无载波数据</div>`

                const caActive = hasNRCA || hasLTECA
                const bwEl = document.getElementById('NSM_bw_total')
                bwEl.textContent = bwSum.val > 0 ? bwSum.val + ' MHz' : (bwSum.est > 0 ? '~' + bwSum.est + ' MHz' : '-')
                bwEl.style.color = caActive ? '#22c55e' : 'rgba(255,255,255,0.85)'

                const typeEl = document.getElementById('NSM_type'), caBadge = document.getElementById('NSM_ca_badge')
                let dt2 = ntype
                if (caActive && is5G) { dt2 = ntype.replace(/\bSA\b/i,'A').replace(/\bNSA\b/i,'A'); if (!dt2.includes('A')) dt2 += ' A' }
                // 4G/LTE 统一：无聚合 → "4G"，有聚合 → "4G+"
                if (is4G) { dt2 = caActive ? '4G+' : '4G' }
                typeEl.textContent = dt2
                if (caActive) {
                    caBadge.style.display = 'inline-block'
                    caBadge.style.background = is5G ? '#3b82f6' : '#22c55e'
                    caBadge.style.color = '#fff'
                    caBadge.style.boxShadow = 'none'
                } else {
                    caBadge.style.display = 'none'
                }

            } catch (e) {
                LOG('refresh error', e)
            } finally {
                refreshing = false
            }
        }

        // ===== 详情日志 =====
        document.getElementById('NSM_detail_btn').addEventListener('click', () => {
            logDom.style.display = logDom.style.display === 'none' ? 'block' : 'none'
        })

        // ===== 启动 =====
        pushLog(`📶 网络信号监控已启动 (${VERSION} · 左右平衡布局 · 载波默认折叠 · 1s 刷新)`, 'info')
        // 恢复用户上次载波区展开/收起状态
        setCarriersOpen(localStorage.getItem(CARRIERS_KEY) === '1')
        // 恢复用户上次全局折叠状态（默认展开）
        setCollapsed(localStorage.getItem(COLLAPSE_KEY) === '1')
        setQualityStandardsOpen(localStorage.getItem(QUALITY_STD_KEY) === '1')
        renderQuality(evaluateCarrierQuality([]))
        refresh()

        let intervalId = setInterval(refresh, 1000)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                clearInterval(intervalId)
                LOG('页面隐藏，停止轮询')
            } else {
                refresh()
                intervalId = setInterval(refresh, 1000)
                LOG('页面显示，恢复轮询')
            }
        })

        LOG(`网络信号监控 ${VERSION} 已启动`)
    }
})()